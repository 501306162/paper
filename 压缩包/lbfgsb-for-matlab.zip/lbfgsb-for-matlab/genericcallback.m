function genericcallback (t, f, x)
  fprintf('%3d  %0.3g \n', t, f);
  