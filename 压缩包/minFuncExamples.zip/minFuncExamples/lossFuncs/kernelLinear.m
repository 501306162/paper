function [XX] = kernelLinear(X1,X2,varargin)
XX = X1*X2';