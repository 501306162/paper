function err=squared_difference_double(V,U)
% err=sum((V(:)-U(:)).^2)/numel(V);
err=sum((V(:)-U(:)).^2)/numel(V);

